# Violations Desk — OSHA proxy

A Cloudflare Worker that calls the DOL Open Data Portal v4 OSHA datasets and
returns records already shaped for the Violations Desk UI. The DOL API key is a
Worker secret, so it never reaches the browser.

## Deploy

```bash
cd worker
npx wrangler secret put DOL_API_KEY     # paste your key when prompted
npx wrangler deploy
```

Set `ALLOWED_ORIGINS` in `wrangler.toml` to the origin that serves the page
(for example `https://dan.github.io`) before going past local testing. Leaving
it empty allows any origin, which is fine while developing.

## Endpoints

| Route | Purpose |
| --- | --- |
| `/health` | returns `{ ok: true }` — use it to confirm the deploy |
| `/search?name=ACME&state=CA&since=2021-01-01` | matching inspections: activity number, date, state, name |
| `/inspection?activity=1844208015` | one mapped record |
| `/inspection?name=ACME&state=CA&since=2021-01-01&limit=10` | mapped records for every match |

Add `&raw=1` to an `/inspection` call to see the unmapped DOL rows. Use that to
confirm field names on your first run.

Each request fans out to the inspection, violation, violation_event and
accident_injury datasets, plus accident when there is an injury record.
Responses are cached for 15 minutes at the edge, since DOL updates daily.

## Point the page at it

The page reads its Worker URL from `API.base` in
`violations-desk-manual-template.html`. Set it to your deployed Worker, then
open the page with the inspection in the query string:

```
violations-desk-manual-template.html?activity=1844208015
violations-desk-manual-template.html?name=ACME&state=CA&since=2021-01-01
?api=https://preview.example.workers.dev&activity=1844208015   # override the Worker per load
```

Refresh OSHA Data re-pulls the same query. With no query string it adds a blank
inspection, as before.

## Checks for the first live run

Two field names were inferred rather than read from DOL's published column
list. Confirm them with `&raw=1`:

- `initial_viol_type` on the violation dataset, which feeds Initial Citation Type
- whether `accident_injury` joins to an inspection on `rel_insp_nr`

`natureOfInjury` and `occupation` come back as numeric codes and need OSHA's IN
and OCC tables to become readable.
